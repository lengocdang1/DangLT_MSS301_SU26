package fu.DE180613.userservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class De180613UserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(De180613UserServiceApplication.class, args);
	}

}
